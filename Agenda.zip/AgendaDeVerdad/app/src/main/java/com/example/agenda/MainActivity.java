package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.LinkedList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    int iterador;
    List<Persona>personas;
    EditText nombre ;
    EditText apellido;
    EditText telefono;

    Button anteriorButton;
    Button guardarButton;
    Button posteriorButton;
    Button editarButton;

    boolean isEditando;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nombre =(EditText) findViewById(R.id.nombre);
        apellido=(EditText) findViewById(R.id.apellido);
        telefono=(EditText) findViewById(R.id.telefono);

        anteriorButton= (Button) findViewById(R.id.anteriorButton);
        guardarButton= (Button) findViewById(R.id.guardarButton);
        posteriorButton=(Button) findViewById(R.id.posteriorButton);
        editarButton=(Button)findViewById(R.id.editarButton);

        isEditando=false;

        posteriorButton.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                iterador++;

                if(iterador<personas.size())
                    actualizarUI(personas.get(iterador).getNombre(), personas.get(iterador).getApellido(), personas.get(iterador).getTelefono());

                else
                    actualizarUI("", "", "");
            }
        });

        anteriorButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                iterador=0;
                actualizarUI(personas.get(iterador).getNombre(),personas.get(iterador).getApellido(),personas.get(iterador).getTelefono());
                return true;
            }
        });

        anteriorButton.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {

                iterador--;
                actualizarUI(personas.get(iterador).getNombre(), personas.get(iterador).getApellido(), personas.get(iterador).getTelefono());
            }
        });

        posteriorButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                iterador=personas.size();
                actualizarUI("","","");
                return true;
            }
        });

        guardarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                personas.add(new Persona(String.valueOf(nombre.getText()),String.valueOf(apellido.getText()),String.valueOf(telefono.getText())));
                guardarButton.setEnabled(false);
                actualizarUI(personas.get(iterador).getNombre(), personas.get(iterador).getApellido(), personas.get(iterador).getTelefono());

                if(isEditando){
                    nombre.setEnabled(false);
                    apellido.setEnabled(false);
                    telefono.setEnabled(false);
                    guardarButton.setEnabled(false);

                    isEditando=false;
                    editarButton.setText("EDITAR");
                }
            }
        });

        editarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                if(!isEditando) {
                    nombre.setEnabled(true);
                    apellido.setEnabled(true);
                    telefono.setEnabled(true);

                    anteriorButton.setEnabled(false);
                    posteriorButton.setEnabled(false);
                    isEditando=true;
                    editarButton.setText("CANCELAR");
                }
                else{
                    nombre.setEnabled(false);
                    apellido.setEnabled(false);
                    telefono.setEnabled(false);

                    if(iterador<personas.size())
                        actualizarUI(personas.get(iterador).getNombre(), personas.get(iterador).getApellido(), personas.get(iterador).getTelefono());
                    else
                        actualizarUI("","","");

                    isEditando=false;
                    editarButton.setText("EDITAR");
                }

            }
        });

        iterador=0;
        personas=iniciaPersonas();

        actualizarUI(personas.get(iterador).getNombre(), personas.get(iterador).getApellido(), personas.get(iterador).getTelefono());

        nombre.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(iterador<personas.size())
                    if(!nombre.getText().toString().equals(personas.get(iterador).getNombre()))
                        guardarButton.setEnabled(true);
                    else if(!apellido.getText().toString().equals(personas.get(iterador).getApellido()))
                        guardarButton.setEnabled(true);
                    else if(!telefono.getText().toString().equals(personas.get(iterador).getTelefono()))
                        guardarButton.setEnabled(true);
                    else
                        guardarButton.setEnabled(false);
                else
                    guardarButton.setEnabled(true);
            }
        });

        apellido.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(iterador<personas.size())
                    if(!apellido.getText().toString().equals(personas.get(iterador).getApellido()))
                        guardarButton.setEnabled(true);
                    else if(!nombre.getText().toString().equals(personas.get(iterador).getNombre()))
                        guardarButton.setEnabled(true);
                    else if(!telefono.getText().toString().equals(personas.get(iterador).getTelefono()))
                        guardarButton.setEnabled(true);
                    else
                        guardarButton.setEnabled(false);
                else
                    guardarButton.setEnabled(true);
            }
        });

        telefono.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                if(iterador<personas.size())
                    if(!telefono.getText().toString().equals(personas.get(iterador).getTelefono()))
                        guardarButton.setEnabled(true);
                    else if(!apellido.getText().toString().equals(personas.get(iterador).getApellido()))
                        guardarButton.setEnabled(true);
                    else if(!nombre.getText().toString().equals(personas.get(iterador).getNombre()))
                        guardarButton.setEnabled(true);
                    else
                        guardarButton.setEnabled(false);
                else
                    guardarButton.setEnabled(true);
            }
        });


    }



    private void actualizarUI(String nombre, String apellido, String telefono) {

        this.nombre.setText(nombre);
        this.apellido.setText(apellido);
        this.telefono.setText(telefono);
        anteriorButton.setEnabled(iterador>0);
        posteriorButton.setEnabled(iterador<personas.size());
        guardarButton.setEnabled(false);
        this.nombre.setEnabled(false);
        this.apellido.setEnabled(false);
        this.telefono.setEnabled(false);
    }

    private List<Persona> iniciaPersonas(){
        List<Persona> personas=new LinkedList<>();
        personas.add(new Persona("Marc","Jovani","611111111"));
        personas.add(new Persona("Selena","Albala","622222222"));
        personas.add(new Persona("Hector","Lapaz","633333333"));

        return personas;
    }
}